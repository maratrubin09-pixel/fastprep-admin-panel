# 🚀 Развертывание Fast Prep USA Admin Panel на Digital Ocean

## 📋 Предварительные требования

### 1. Digital Ocean Droplet
- **Размер**: Минимум 2GB RAM, 1 CPU, 50GB SSD
- **ОС**: Ubuntu 20.04 LTS или новее
- **Регион**: Выберите ближайший к вашим клиентам

### 2. Домен и DNS
- **Поддомен**: `admin.fastprepusa.com` (или ваш выбор)
- **DNS**: Настройте A-запись, указывающую на IP вашего сервера

### 3. Локальные требования
- Node.js 18+ 
- npm
- SSH доступ к серверу
- rsync

## 🚀 Быстрое развертывание

### Шаг 1: Подготовка сервера
```bash
# Создайте новый Droplet на Digital Ocean
# Выберите Ubuntu 20.04 LTS
# Минимум 2GB RAM, 1 CPU
```

### Шаг 2: Получение IP адреса
```bash
# Найдите IP адрес вашего сервера в панели Digital Ocean
# Пример: 123.456.789.0
```

### Шаг 3: Запуск развертывания
```bash
# Перейдите в папку проекта
cd /Users/maratrubin/fastprep-admin-panel

# Запустите скрипт развертывания
./quick-deploy.sh YOUR_SERVER_IP

# Пример:
./quick-deploy.sh 123.456.789.0
```

### Шаг 4: Настройка DNS
```bash
# В панели управления вашего домена добавьте A-запись:
# admin.fastprepusa.com -> YOUR_SERVER_IP
```

## 🔧 Ручное развертывание (если нужно)

### 1. Подключение к серверу
```bash
ssh root@YOUR_SERVER_IP
```

### 2. Установка зависимостей
```bash
# Обновление системы
apt update && apt upgrade -y

# Установка Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt-get install -y nodejs

# Установка PM2
npm install -g pm2

# Установка PostgreSQL
apt-get install -y postgresql postgresql-contrib

# Установка Nginx
apt-get install -y nginx
```

### 3. Настройка базы данных
```bash
# Создание базы данных
sudo -u postgres psql << 'EOF'
CREATE DATABASE fastprep_admin;
CREATE USER fastprep_admin WITH PASSWORD 'admin123';
GRANT ALL PRIVILEGES ON DATABASE fastprep_admin TO fastprep_admin;
\q
EOF
```

### 4. Копирование файлов
```bash
# Создание директории
mkdir -p /var/www/fastprep-admin
mkdir -p /var/www/fastprep-admin/public

# Копирование backend (с вашего локального компьютера)
rsync -avz backend/ root@YOUR_SERVER_IP:/var/www/fastprep-admin/

# Копирование frontend build
rsync -avz frontend/build/ root@YOUR_SERVER_IP:/var/www/fastprep-admin/public/
```

### 5. Настройка приложения
```bash
# На сервере
cd /var/www/fastprep-admin

# Установка зависимостей
npm install --production

# Создание .env файла
cat > .env << 'EOF'
NODE_ENV=production
PORT=5001
DB_HOST=localhost
DB_PORT=5432
DB_NAME=fastprep_admin
DB_USER=fastprep_admin
DB_PASSWORD=admin123
JWT_SECRET=your_jwt_secret_key_change_this
JWT_REFRESH_SECRET=your_refresh_secret_key_change_this
FRONTEND_URL=https://admin.fastprepusa.com
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
EOF
```

### 6. Запуск приложения
```bash
# Запуск с PM2
pm2 start server.js --name "fastprep-admin"
pm2 save
pm2 startup
```

### 7. Настройка Nginx
```bash
# Создание конфигурации
cat > /etc/nginx/sites-available/fastprep-admin << 'EOF'
server {
    listen 80;
    server_name admin.fastprepusa.com;
    
    # Frontend
    location / {
        root /var/www/fastprep-admin/public;
        try_files $uri $uri/ /index.html;
    }
    
    # Backend API
    location /api {
        proxy_pass http://localhost:5001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Socket.io
    location /socket.io/ {
        proxy_pass http://localhost:5001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

# Активация сайта
ln -sf /etc/nginx/sites-available/fastprep-admin /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
```

### 8. Настройка SSL
```bash
# Установка Certbot
apt-get install -y certbot python3-certbot-nginx

# Получение SSL сертификата
certbot --nginx -d admin.fastprepusa.com --non-interactive --agree-tos --email admin@fastprepusa.com
```

## 🔐 Безопасность

### Обязательные изменения после развертывания:

1. **Измените пароли базы данных**:
```bash
sudo -u postgres psql
ALTER USER fastprep_admin WITH PASSWORD 'your_secure_password';
```

2. **Обновите JWT секреты**:
```bash
# В .env файле замените:
JWT_SECRET=your_very_long_and_secure_jwt_secret_key
JWT_REFRESH_SECRET=your_very_long_and_secure_refresh_secret_key
```

3. **Измените пароль администратора**:
- Войдите в систему: `admin@fastprepusa.com / admin123`
- Перейдите в Settings → Users
- Измените пароль администратора

4. **Настройте файрвол**:
```bash
ufw allow ssh
ufw allow 'Nginx Full'
ufw enable
```

## 📊 Мониторинг

### Проверка статуса приложения:
```bash
# Статус PM2
pm2 status

# Логи приложения
pm2 logs fastprep-admin

# Статус Nginx
systemctl status nginx

# Статус PostgreSQL
systemctl status postgresql
```

### Перезапуск сервисов:
```bash
# Перезапуск приложения
pm2 restart fastprep-admin

# Перезапуск Nginx
systemctl reload nginx

# Перезапуск PostgreSQL
systemctl restart postgresql
```

## 🔄 Обновление приложения

### Для обновления кода:
```bash
# На локальном компьютере
cd /Users/maratrubin/fastprep-admin-panel

# Сборка frontend
cd frontend && npm run build && cd ..

# Копирование обновлений
rsync -avz backend/ root@YOUR_SERVER_IP:/var/www/fastprep-admin/
rsync -avz frontend/build/ root@YOUR_SERVER_IP:/var/www/fastprep-admin/public/

# На сервере
ssh root@YOUR_SERVER_IP
cd /var/www/fastprep-admin
npm install --production
pm2 restart fastprep-admin
```

## 🆘 Устранение неполадок

### Приложение не запускается:
```bash
# Проверьте логи
pm2 logs fastprep-admin

# Проверьте статус
pm2 status

# Перезапустите
pm2 restart fastprep-admin
```

### База данных недоступна:
```bash
# Проверьте статус PostgreSQL
systemctl status postgresql

# Проверьте подключение
sudo -u postgres psql -c "SELECT version();"
```

### Nginx ошибки:
```bash
# Проверьте конфигурацию
nginx -t

# Проверьте логи
tail -f /var/log/nginx/error.log
```

## 📞 Поддержка

После успешного развертывания ваше приложение будет доступно по адресу:
**https://admin.fastprepusa.com**

**Данные для входа:**
- Email: `admin@fastprepusa.com`
- Password: `admin123`

**Не забудьте изменить пароль после первого входа!**
