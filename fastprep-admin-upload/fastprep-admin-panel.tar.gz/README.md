# Fast Prep USA Admin Panel

Полнофункциональная админ-панель для управления клиентами, мессенджерами и задачами компании Fast Prep USA.

## 🚀 Быстрый старт

### Локальная разработка

1. **Клонируйте репозиторий**
```bash
git clone <repository-url>
cd fastprep-admin-panel
```

2. **Настройте backend**
```bash
cd backend
npm install
cp env.example .env
# Отредактируйте .env файл с вашими настройками
npm run dev
```

3. **Настройте frontend**
```bash
cd frontend
npm install
npm start
```

4. **Настройте базу данных**
```bash
cd backend
npm run migrate
npm run seed
```

### Production Deployment

1. **Настройте production окружение**
```bash
chmod +x setup-production.sh
./setup-production.sh
```

2. **Настройте базу данных**
```bash
chmod +x setup-database.sh
./setup-database.sh
```

3. **Запустите приложение**
```bash
chmod +x deploy-production.sh
./deploy-production.sh
```

4. **Настройте SSL (опционально)**
```bash
chmod +x setup-ssl.sh
./setup-ssl.sh
```

## 🧪 Тестирование мессенджеров

```bash
chmod +x test-messengers.sh
./test-messengers.sh
```

## 📋 Возможности

### ✅ Реализовано
- **Система аутентификации** - JWT токены, роли и права доступа
- **Интеграция мессенджеров** - WhatsApp, Telegram, Facebook, Instagram, Email
- **Real-time обновления** - Socket.io для мгновенных уведомлений
- **Единый inbox** - все сообщения в одном интерфейсе
- **Webhook'и** - автоматическая обработка входящих сообщений
- **WordPress интеграция** - прием заявок с сайта

### 🚧 В разработке
- CRM модуль (клиенты, лиды, воронка продаж)
- Таск-менеджер (задачи, назначения, статусы)
- Аналитика и отчеты
- Файловое хранилище
- Система уведомлений

## 🔧 Конфигурация

### Переменные окружения

#### Backend (.env)
```env
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=fastprep_admin_dev
DB_USER=postgres
DB_PASSWORD=password

# JWT
JWT_SECRET=your-super-secret-jwt-key
JWT_REFRESH_SECRET=your-super-secret-refresh-key

# Server
PORT=5000
FRONTEND_URL=http://localhost:3000

# Messengers
WHATSAPP_TOKEN=your-whatsapp-token
WHATSAPP_PHONE_NUMBER_ID=your-phone-number-id
TELEGRAM_BOT_TOKEN=your-telegram-bot-token
FACEBOOK_ACCESS_TOKEN=your-facebook-token
FACEBOOK_APP_SECRET=your-facebook-secret
INSTAGRAM_ACCESS_TOKEN=your-instagram-token

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
FROM_EMAIL=noreply@fastprepusa.com

# WordPress
WORDPRESS_WEBHOOK_SECRET=your-webhook-secret
```

#### Frontend (.env)
```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_SOCKET_URL=http://localhost:5000
```

## 🌐 API Endpoints

### Аутентификация
- `POST /api/auth/login` - Вход в систему
- `POST /api/auth/register` - Регистрация
- `POST /api/auth/refresh` - Обновление токена
- `GET /api/auth/profile` - Профиль пользователя

### Пользователи и роли
- `GET /api/users` - Список пользователей
- `POST /api/users` - Создание пользователя
- `PUT /api/users/:id` - Обновление пользователя
- `DELETE /api/users/:id` - Удаление пользователя
- `GET /api/roles` - Список ролей
- `POST /api/roles` - Создание роли

### Сообщения
- `GET /api/messages/conversations` - Список разговоров
- `GET /api/messages/conversations/:id` - Детали разговора
- `GET /api/messages/conversations/:id/messages` - Сообщения разговора
- `POST /api/messages/send` - Отправка сообщения
- `PUT /api/messages/conversations/:id/assign` - Назначение ответственного
- `PUT /api/messages/conversations/:id/status` - Обновление статуса

### Webhook'и
- `POST /api/webhooks/whatsapp` - WhatsApp webhook
- `POST /api/webhooks/telegram` - Telegram webhook
- `POST /api/webhooks/facebook` - Facebook webhook
- `POST /api/webhooks/instagram` - Instagram webhook
- `POST /api/webhooks/email` - Email webhook
- `POST /api/webhooks/wordpress` - WordPress webhook
- `GET /api/webhooks/health` - Проверка состояния

## 🔌 Интеграция мессенджеров

### WhatsApp Business API
1. Получите токен доступа в Facebook Business
2. Настройте webhook URL: `https://yourdomain.com/api/webhooks/whatsapp`
3. Добавьте токен в переменную `WHATSAPP_TOKEN`

### Telegram Bot
1. Создайте бота через @BotFather
2. Получите токен бота
3. Настройте webhook: `https://yourdomain.com/api/webhooks/telegram`
4. Добавьте токен в переменную `TELEGRAM_BOT_TOKEN`

### Facebook Messenger
1. Создайте Facebook App
2. Настройте webhook URL: `https://yourdomain.com/api/webhooks/facebook`
3. Добавьте токены в переменные `FACEBOOK_ACCESS_TOKEN` и `FACEBOOK_APP_SECRET`

### Instagram Direct
1. Настройте Instagram Business Account
2. Настройте webhook URL: `https://yourdomain.com/api/webhooks/instagram`
3. Добавьте токен в переменную `INSTAGRAM_ACCESS_TOKEN`

### Email
1. Настройте SMTP сервер (Gmail, SendGrid, etc.)
2. Настройте webhook для входящих писем
3. Добавьте настройки в переменные `SMTP_*`

## 🗄️ База данных

### Основные таблицы
- `users` - Пользователи системы
- `roles` - Роли с правами доступа
- `customers` - Клиенты CRM
- `leads` - Лиды/заявки
- `conversations` - Разговоры из мессенджеров
- `messages` - Сообщения
- `tasks` - Задачи
- `activity_logs` - Логи действий
- `files` - Файлы

### Миграции
```bash
cd backend
npm run migrate        # Применить миграции
npm run migrate:undo   # Откатить миграции
npm run seed          # Заполнить тестовыми данными
```

## 🚀 Deployment на Digital Ocean

### Требования
- Ubuntu 22.04 LTS
- 2GB RAM минимум
- 20GB SSD
- Домен (например, admin.fastprepusa.com)

### Автоматический deployment
```bash
# На сервере
curl -fsSL https://raw.githubusercontent.com/your-repo/fastprep-admin-panel/main/deploy.sh | bash
```

### Ручной deployment
1. **Установите зависимости**
```bash
sudo apt update && sudo apt upgrade -y
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs nginx postgresql-client
sudo npm install -g pm2 serve
```

2. **Настройте приложение**
```bash
git clone <repository-url> /var/www/fastprep-admin
cd /var/www/fastprep-admin
chmod +x setup-production.sh
./setup-production.sh
```

3. **Настройте Nginx**
```bash
sudo cp nginx.conf /etc/nginx/sites-available/fastprep-admin
sudo ln -s /etc/nginx/sites-available/fastprep-admin /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

4. **Настройте SSL**
```bash
sudo certbot --nginx -d admin.fastprepusa.com
```

5. **Запустите приложение**
```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

## 🔒 Безопасность

- JWT токены с коротким временем жизни
- Refresh токены для обновления сессий
- Хеширование паролей (bcrypt)
- Rate limiting для API
- CORS настройки
- HTTPS обязательно в production
- Валидация всех входных данных
- Защита от SQL injection (Sequelize ORM)

## 📊 Мониторинг

### PM2 команды
```bash
pm2 status              # Статус процессов
pm2 logs               # Просмотр логов
pm2 monit              # Мониторинг в реальном времени
pm2 restart all        # Перезапуск всех процессов
pm2 stop all           # Остановка всех процессов
```

### Логи
- Backend: `logs/backend-*.log`
- Frontend: `logs/frontend-*.log`
- Nginx: `/var/log/nginx/`

## 🧪 Тестирование

### Unit тесты
```bash
cd backend
npm test
```

### Integration тесты
```bash
chmod +x test-messengers.sh
./test-messengers.sh
```

### E2E тесты
```bash
cd frontend
npm run test:e2e
```

## 📝 Документация

- [API Documentation](docs/api.md)
- [Database Schema](docs/database.md)
- [Messenger Integration](docs/messengers.md)
- [Deployment Guide](docs/deployment.md)
- [User Manual](docs/user-manual.md)

## 🤝 Поддержка

- Email: support@fastprepusa.com
- Telegram: @fastprepusa_support
- Issues: [GitHub Issues](https://github.com/your-repo/issues)

## 📄 Лицензия

MIT License - см. файл [LICENSE](LICENSE)

---

**Fast Prep USA Admin Panel** - Управляйте бизнесом эффективно! 🚀